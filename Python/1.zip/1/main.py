
# Moja prva skripta

# "Hello World" -> String -> Text
# 20, 5 -> broj -> integer
# 12.3 -> broj -> float/decimal

print("Hello world")
print(20)
print(12.3)

# variable /varijable / promenljive

name = "Boris"
print(name)

# Napraviti 2 verijable: age, height ->ispisite
age = 45
height = 170
print(age,height)

# bool -> boolean
is_programmer = True
is_night_mode = False
print(is_programmer,is_night_mode)

# Vezba
# Napraviti novi fajl "vezba.py"
# Napraviti sledece variables: program_name, version,is_new_program
# Tipovi koji morate koristiti: string, decimal, boolean

name = "admin"
password = "mojaSifra"
#ako je ime admin i AKO je sifra mojaSifra print("DObrodosao admine!")
# Ako je ime "toma" i ako je sifra "123456" print("Dobrodosao Tomo!")
# Ako je ime "marija" i ako je sifra "554231" print("Dobrodosla Marija!")
# else print ("Niste administrator! Pogresna sifra ili ime!")

if name == "admin" and password == "mojaSifra":
    print("Dobro dosao admine!")
elif name == "toma" and password == "123456":
    print("Dobro dosao Tomo")
elif name == "marija" and password == "554231":
    print("Dobrodosla Marija!")
else :
    print("Niste administrator! Pogresna sifra ili ime!")






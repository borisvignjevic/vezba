
age = 45
allowed_age = 18

# if 31 >=18
if age >= allowed_age:
    print("Punoltni ste")
else:
    print("Niste punoletni")

age_difference = age - allowed_age

# 31 - 18 = 13
print(f"Korisnik ima vise od {age_difference} godina razlike")

# Vezba: Napravitti 3 varijable "name", "last_name" i "age" i postavite neke vrednosti

name = "Boris"
last_name = "Vignjevic"
age = 45

# Ja se zovem IME, a prezivam se PREZIME i imam GODINA godina
print("Ja se zovem "+name+" , a prezivam se "+last_name+" i imam "+str(age)+" godina")
print(f"Ja se zovem {name}, a prezivam se {last_name} i imam {str(age)} godina")
price = 2000
tax = 0.22
product_tax = price*tax

full_name = name+" "+last_name

print(product_tax, full_name)

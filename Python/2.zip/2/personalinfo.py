

# dictionary
person = {
    "name" : "Toma",
    "last_name" : "Nikolic",
    "age" : 31,
    "hobbies" : ["fishing","programming", "cooking"]
}

print(person["age"], person["hobbies"][1])


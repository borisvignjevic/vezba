
# loop /petlje

racun = ["hleb", "mleko", "jogurt", "novine","jaja","voda", "secer"]


for stavka in racun:
    print(stavka)